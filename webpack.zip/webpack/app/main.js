require('./main.css');
require('./index.scss');

'use strict';
var component = require('./component.js');
document.body.appendChild(component());