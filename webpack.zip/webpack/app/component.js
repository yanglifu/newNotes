'use strict';
module.exports = function () {
    var element = document.createElement('h1');
    element.innerHTML = '神武';
    return element;
};