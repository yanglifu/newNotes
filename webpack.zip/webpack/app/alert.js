$(function(){
	$("#content").click(function(){
		alert(1);
	});
});